const fs = require('fs');
const path = require('path');

// Parse raw document into questions
const srcPath = 'C:\\Users\\Admin\\.gemini\\antigravity\\brain\\72e5b307-8855-4bd0-bc04-a547389db238\\.system_generated\\steps\\2\\content.md';
const destPath = 'C:\\Users\\Admin\\.gemini\\antigravity\\scratch\\quizlet-learn\\src\\data\\questions.ts';

console.log('Reading source file...');
const raw = fs.readFileSync(srcPath, 'utf8');
const lines = raw.split(/\r?\n/);
console.log(`Read ${lines.length} lines.`);

function cleanText(text) {
  return text
    .replace(/SOẠN ĐỘC QUYỀN BỞI THỦY TIÊN/gi, '')
    .replace(/\(soạn bởi thủy Tiên nha\)/gi, '')
    .replace(/soạn bởi thủy Tiên/gi, '')
    .replace(/\r/g, '')
    .trim();
}

const parsedQuestions = [];
let currentQuestionTextLines = [];
let currentOptions = {};
let currentAnswer = '';
let currentExplanation = '';
let currentHasImage = false;

function flushQuestion() {
  const text = cleanText(currentQuestionTextLines.join(' '));
  if (text && Object.keys(currentOptions).length >= 2 && currentAnswer) {
    const opts = {
      A: currentOptions['A'] || '',
      B: currentOptions['B'] || '',
      C: currentOptions['C'] || '',
      D: currentOptions['D'] || ''
    };
    if (currentOptions['E']) {
      opts['E'] = currentOptions['E'];
    }

    parsedQuestions.push({
      id: parsedQuestions.length + 1,
      question: text,
      options: opts,
      answer: currentAnswer,
      explanation: currentExplanation,
      hasImage: currentHasImage
    });
  }
  currentQuestionTextLines = [];
  currentOptions = {};
  currentAnswer = '';
  currentExplanation = '';
  currentHasImage = false;
}

let i = 0;
while (i < lines.length) {
  const line = lines[i];
  const trimmed = line.trim();

  if (!trimmed || trimmed.startsWith('Source:') || trimmed.startsWith('---')) {
    i++;
    continue;
  }

  // Handle 'Hình ảnh:' indicator
  if (trimmed.startsWith('Hình ảnh:')) {
    if (parsedQuestions.length > 0 && currentQuestionTextLines.length === 0 && Object.keys(currentOptions).length === 0) {
      parsedQuestions[parsedQuestions.length - 1].hasImage = true;
    } else {
      currentHasImage = true;
    }
    i++;
    continue;
  }

  // Check for option line: 'A. ...', 'a. ...', 'A) ...', 'a) ...'
  let optMatch = trimmed.match(/^([a-eA-E])[\.\)]\s*(.*)$/);

  // Check edge case options like 'A 0.72' or 'A decreases...'
  if (!optMatch) {
    const edgeOpt = trimmed.match(/^([a-eA-E])\s+(.*)$/);
    if (edgeOpt) {
      const firstWord = edgeOpt[2].split(/\s+/)[0].toLowerCase().replace(/[^a-z]/g, '');
      const nonOptionFirstWords = new Set([
        'company', 'problem', 'firm', 'group', 'detailed', 'good', 'distinguishing',
        'conventional', 'society', 'buyer', 'marketer', 'product', 'startup',
        'salesperson', 'shoe', 'test', 'customer', 'supplier', 'smallscale',
        'regional', 'radio', 'consumer', 'business', 'catalog', 'hickory',
        'corporate', 'quantity', 'car', 'number', 'message', 'newspaper',
        'technological', 'toothpaste', 'church', 'tax', 'trademark', 'preferred',
        'tob', 'the', 'when', 'which', 'what', 'an', 'in', 'if', 'for', 'to'
      ]);
      if (!nonOptionFirstWords.has(firstWord)) {
        optMatch = edgeOpt;
      }
    }
  }

  // Check for answer line: single letter, possibly with explanation in parens
  let ansMatch = null;
  if (Object.keys(currentOptions).length >= 2) {
    ansMatch = trimmed.match(/^([a-eA-E])(\s*[\(;].*)?$/i);
    if (!ansMatch && /^[a-eA-E]$/i.test(trimmed)) {
      ansMatch = [trimmed, trimmed, ''];
    }
  }

  // If matched option and not an answer
  if (optMatch && (!ansMatch || optMatch[2].length > 0)) {
    const optLetter = optMatch[1].toUpperCase();
    currentOptions[optLetter] = optMatch[2].trim();
    i++;
    continue;
  }

  // If matched answer
  if (ansMatch && !optMatch) {
    const letter = ansMatch[1].toUpperCase();
    let fullAnsText = trimmed;
    let parenDepth = (fullAnsText.match(/\(/g) || []).length - (fullAnsText.match(/\)/g) || []).length;
    while (parenDepth > 0 && i + 1 < lines.length) {
      i++;
      fullAnsText += ' ' + lines[i].trim();
      parenDepth = (fullAnsText.match(/\(/g) || []).length - (fullAnsText.match(/\)/g) || []).length;
    }

    let expl = '';
    const mExp = fullAnsText.match(/^[a-eA-E]\s*[\(;]?\s*(.*)$/i);
    if (mExp && mExp[1]) {
      expl = mExp[1].replace(/^\(/, '').replace(/\)$/, '').trim();
    }

    currentAnswer = letter;
    currentExplanation = expl;
    flushQuestion();
    i++;
    continue;
  }

  // Otherwise, it's question text line
  if (Object.keys(currentOptions).length > 0 && currentAnswer) {
    flushQuestion();
  }

  currentQuestionTextLines.push(trimmed);
  i++;
}
flushQuestion();

console.log(`Parsed total of ${parsedQuestions.length} questions.`);

// Reassign sequential IDs
parsedQuestions.forEach((q, idx) => {
  q.id = idx + 1;
});

// Generate TypeScript content
const tsHeader = `export interface Question {
  id: number;
  question: string;
  options: { A: string; B: string; C: string; D: string; E?: string };
  answer: 'A' | 'B' | 'C' | 'D' | 'E';
  explanation: string;
  hasImage: boolean;
}

export const questions: Question[] = `;

const tsContent = `${tsHeader}${JSON.stringify(parsedQuestions, null, 2)};\n`;

fs.writeFileSync(destPath, tsContent, 'utf8');
console.log(`Successfully written output to: ${destPath}`);
