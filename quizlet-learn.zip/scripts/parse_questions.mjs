#!/usr/bin/env node
/**
 * Parse quiz questions from the Google Docs export file.
 * Run: node scripts/parse_questions.mjs
 */
import { readFileSync, writeFileSync, mkdirSync } from 'fs';
import { dirname } from 'path';

const INPUT_FILE = String.raw`C:\Users\Admin\.gemini\antigravity\brain\72e5b307-8855-4bd0-bc04-a547389db238\.system_generated\steps\2\content.md`;
const OUTPUT_FILE = String.raw`C:\Users\Admin\.gemini\antigravity\scratch\quizlet-learn\src\data\questions.ts`;

function cleanText(text) {
  text = text.trim();
  text = text.replace(/\s*SOẠN ĐỘC QUYỀN BỞI THỦY TIÊN\s*/g, '');
  text = text.replace(/\s+/g, ' ');
  return text.trim();
}

function isOptionLine(line) {
  return /^[A-D][\.\)]\s+/.test(line.trim()) || /^[A-D]\s+\S/.test(line.trim());
}

function isOptionForLetter(line, letter) {
  const s = line.trim();
  return new RegExp(`^${letter}[\\.)\\s]`).test(s);
}

function extractOptionText(line) {
  const s = line.trim();
  let m = s.match(/^([A-D])[\.\)]\s+(.*)/);
  if (m) return { letter: m[1], text: m[2].trim() };
  m = s.match(/^([A-D])\s+(.+)/);
  if (m) return { letter: m[1], text: m[2].trim() };
  return null;
}

function isAnswerLine(line) {
  const s = line.trim();
  return /^[A-D]\s*$/.test(s) || /^[A-D]\s*\(/.test(s);
}

function extractAnswer(line) {
  const s = line.trim();
  let m = s.match(/^([A-D])\s*$/);
  if (m) return { letter: m[1], explanation: '' };
  m = s.match(/^([A-D])\s*\((.*)/);
  if (m) return { letter: m[1], explanation: m[2] };
  return null;
}

function parseQuestions(lines) {
  const questions = [];
  let i = 0;
  const n = lines.length;

  // Skip header
  while (i < n && (!lines[i].trim() || lines[i].trim().startsWith('Source:') || lines[i].trim() === '---')) {
    i++;
  }

  while (i < n) {
    // Skip blank lines
    while (i < n && !lines[i].trim()) i++;
    if (i >= n) break;

    let line = lines[i].trim();

    // Skip "Hình ảnh:" sections
    if (line.startsWith('Hình ảnh:')) {
      i++;
      let blankCount = 0;
      while (i < n) {
        if (!lines[i].trim()) {
          blankCount++;
          if (blankCount >= 2) { i++; break; }
        } else {
          blankCount = 0;
        }
        i++;
      }
      continue;
    }

    // Skip standalone answer letters
    if (/^[A-D]\s*$/.test(line)) { i++; continue; }
    
    // Skip orphaned answer+explanation
    if (/^[A-D]\s*\(/.test(line)) {
      i++;
      while (i < n && lines[i].trim()) i++;
      continue;
    }

    // Skip if this is an option line (orphaned)
    if (isOptionLine(line) && !/^[A-D][\.\)]\s+.*[?:]/.test(line)) {
      i++;
      continue;
    }

    // Collect question text
    const qLines = [];
    while (i < n) {
      line = lines[i].trim();
      if (!line) {
        // Look ahead for options
        let j = i + 1;
        while (j < n && !lines[j].trim()) j++;
        if (j < n && isOptionForLetter(lines[j], 'A')) {
          i = j;
          break;
        }
        if (qLines.length > 0) {
          // Check if we've gone too far
          let k = j;
          let foundOpt = false;
          while (k < n && k < j + 5) {
            if (isOptionForLetter(lines[k], 'A')) { foundOpt = true; break; }
            if (lines[k].trim()) break;
            k++;
          }
          if (foundOpt) { i = k; break; }
          i++;
          break;
        }
        i++;
        continue;
      }
      if (isOptionForLetter(line, 'A')) break;
      if (isAnswerLine(line) && qLines.length > 0) break;
      if (line.startsWith('Hình ảnh:')) break;
      qLines.push(line);
      i++;
    }

    if (!qLines.length) { i++; continue; }

    let questionText = cleanText(qLines.join(' '));
    if (questionText.length < 15) continue;

    // Collect options
    const options = { A: '', B: '', C: '', D: '' };
    let optionsFound = 0;

    for (const expected of ['A', 'B', 'C', 'D']) {
      while (i < n && !lines[i].trim()) i++;
      if (i >= n) break;

      line = lines[i].trim();
      const opt = extractOptionText(line);
      
      if (opt && opt.letter === expected) {
        let optText = opt.text;
        i++;
        // Multi-line option
        while (i < n) {
          const nextLine = lines[i].trim();
          if (!nextLine) break;
          if (isOptionLine(nextLine)) break;
          if (isAnswerLine(nextLine)) break;
          if (nextLine.startsWith('Hình ảnh:')) break;
          optText += ' ' + nextLine;
          i++;
        }
        options[expected] = cleanText(optText);
        optionsFound++;
      } else {
        break;
      }
    }

    if (optionsFound < 2 || !options.A || !options.B) continue;

    // Find answer
    while (i < n && !lines[i].trim()) i++;
    if (i >= n) continue;

    line = lines[i].trim();
    const answerData = extractAnswer(line);
    if (!answerData) continue;

    i++;

    let explanation = answerData.explanation;
    if (explanation) {
      // Collect multi-line explanation
      let parenDepth = (explanation.match(/\(/g) || []).length - (explanation.match(/\)/g) || []).length + 1;
      while (parenDepth > 0 && i < n) {
        line = lines[i].trim();
        if (!line) break;
        if (line.startsWith('Hình ảnh:')) break;
        explanation += ' ' + line;
        parenDepth += (line.match(/\(/g) || []).length - (line.match(/\)/g) || []).length;
        i++;
      }
      explanation = explanation.replace(/\)+\s*$/, '');
      explanation = cleanText(explanation);
    }

    // Check for image
    let hasImage = false;
    while (i < n && !lines[i].trim()) i++;
    if (i < n && lines[i].trim().startsWith('Hình ảnh:')) {
      hasImage = true;
      i++;
      let blankCount = 0;
      while (i < n) {
        if (!lines[i].trim()) {
          blankCount++;
          if (blankCount >= 2) break;
        } else {
          blankCount = 0;
        }
        i++;
      }
    }

    questions.push({
      id: questions.length + 1,
      question: questionText,
      options,
      answer: answerData.letter,
      explanation: explanation || '',
      hasImage,
    });
  }

  return questions;
}

function escapeTs(s) {
  return s.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n').replace(/\r/g, '');
}

function writeTypescript(questions, filepath) {
  mkdirSync(dirname(filepath), { recursive: true });
  
  let content = `export interface Question {
  id: number;
  question: string;
  options: { A: string; B: string; C: string; D: string };
  answer: 'A' | 'B' | 'C' | 'D';
  explanation: string;
  hasImage: boolean;
}

export const questions: Question[] = [\n`;

  for (const q of questions) {
    content += `  {
    id: ${q.id},
    question: "${escapeTs(q.question)}",
    options: {
      A: "${escapeTs(q.options.A)}",
      B: "${escapeTs(q.options.B)}",
      C: "${escapeTs(q.options.C)}",
      D: "${escapeTs(q.options.D)}",
    },
    answer: "${q.answer}",
    explanation: "${escapeTs(q.explanation)}",
    hasImage: ${q.hasImage},
  },\n`;
  }

  content += '];\n';
  writeFileSync(filepath, content, 'utf-8');
  console.log(`Successfully wrote ${questions.length} questions to ${filepath}`);
}

// Main
const raw = readFileSync(INPUT_FILE, 'utf-8');
const lines = raw.split('\n').map(l => l.replace(/\r$/, ''));
console.log(`Read ${lines.length} lines`);

const questions = parseQuestions(lines);
writeTypescript(questions, OUTPUT_FILE);

const withImages = questions.filter(q => q.hasImage).length;
const withExplanations = questions.filter(q => q.explanation).length;
console.log(`Total questions: ${questions.length}`);
console.log(`With images: ${withImages}`);
console.log(`With explanations: ${withExplanations}`);

// Show samples
for (const q of questions.slice(0, 3)) {
  console.log(`\n--- Q${q.id} ---`);
  console.log(`Q: ${q.question.substring(0, 100)}...`);
  console.log(`Options: A=${q.options.A.substring(0,30)} B=${q.options.B.substring(0,30)}`);
  console.log(`Answer: ${q.answer}`);
  console.log(`Explanation: ${q.explanation.substring(0, 80)}`);
  console.log(`HasImage: ${q.hasImage}`);
}
console.log(`\n--- Last Q${questions[questions.length-1].id} ---`);
console.log(`Q: ${questions[questions.length-1].question.substring(0, 100)}`);
