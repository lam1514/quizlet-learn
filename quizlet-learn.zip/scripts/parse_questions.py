import re
import json

src_path = r"C:\Users\Admin\.gemini\antigravity\brain\72e5b307-8855-4bd0-bc04-a547389db238\.system_generated\steps\2\content.md"
dest_path = r"C:\Users\Admin\.gemini\antigravity\scratch\quizlet-learn\src\data\questions.ts"

with open(src_path, "r", encoding="utf-8") as f:
    lines = f.readlines()

def clean_text(text):
    text = re.sub(r"SOẠN ĐỘC QUYỀN BỞI THỦY TIÊN", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\(soạn bởi thủy Tiên nha\)", "", text, flags=re.IGNORECASE)
    text = re.sub(r"soạn bởi thủy Tiên", "", text, flags=re.IGNORECASE)
    return text.strip()

parsed_questions = []
current_question_lines = []
current_options = {}
current_answer = ""
current_explanation = ""
current_has_image = False

non_option_first_words = {
    'company', 'problem', 'firm', 'group', 'detailed', 'good', 'distinguishing',
    'conventional', 'society', 'buyer', 'marketer', 'product', 'startup',
    'salesperson', 'shoe', 'test', 'customer', 'supplier', 'smallscale',
    'regional', 'radio', 'consumer', 'business', 'catalog', 'hickory',
    'corporate', 'quantity', 'car', 'number', 'message', 'newspaper',
    'technological', 'toothpaste', 'church', 'tax', 'trademark', 'preferred',
    'tob', 'the', 'when', 'which', 'what', 'an', 'in', 'if', 'for', 'to'
}

def flush_question():
    global current_question_lines, current_options, current_answer, current_explanation, current_has_image
    text = clean_text(" ".join(current_question_lines))
    if text and len(current_options) >= 2 and current_answer:
        opts = {
            "A": current_options.get("A", ""),
            "B": current_options.get("B", ""),
            "C": current_options.get("C", ""),
            "D": current_options.get("D", "")
        }
        if "E" in current_options:
            opts["E"] = current_options["E"]
        parsed_questions.append({
            "id": len(parsed_questions) + 1,
            "question": text,
            "options": opts,
            "answer": current_answer,
            "explanation": current_explanation,
            "hasImage": current_has_image
        })
    current_question_lines = []
    current_options = {}
    current_answer = ""
    current_explanation = ""
    current_has_image = False

i = 0
while i < len(lines):
    line = lines[i]
    trimmed = line.strip()

    if not trimmed or trimmed.startswith("Source:") or trimmed.startswith("---"):
        i += 1
        continue

    if trimmed.startswith("Hình ảnh:"):
        if parsed_questions and not current_question_lines and not current_options:
            parsed_questions[-1]["hasImage"] = True
        else:
            current_has_image = True
        i += 1
        continue

    opt_match = re.match(r"^([a-eA-E])[\.\)]\s*(.*)$", trimmed)
    if not opt_match:
        edge_opt = re.match(r"^([a-eA-E])\s+(.*)$", trimmed)
        if edge_opt:
            first_word = re.sub(r"[^a-z]", "", edge_opt.group(2).split()[0].lower())
            if first_word not in non_option_first_words:
                opt_match = edge_opt

    ans_match = None
    if len(current_options) >= 2:
        ans_match = re.match(r"^([a-eA-E])(\s*[\(;].*)?$", trimmed, re.IGNORECASE)
        if not ans_match and re.match(r"^[a-eA-E]$", trimmed, re.IGNORECASE):
            ans_match = re.match(r"^([a-eA-E])", trimmed, re.IGNORECASE)

    if opt_match and (not ans_match or opt_match.group(2)):
        current_options[opt_match.group(1).upper()] = opt_match.group(2).strip()
        i += 1
        continue

    if ans_match and not opt_match:
        letter = ans_match.group(1).upper()
        full_ans_text = trimmed
        paren_depth = full_ans_text.count("(") - full_ans_text.count(")")
        while paren_depth > 0 and i + 1 < len(lines):
            i += 1
            full_ans_text += " " + lines[i].strip()
            paren_depth = full_ans_text.count("(") - full_ans_text.count(")")

        expl = ""
        m_exp = re.match(r"^[a-eA-E]\s*[\(;]?\s*(.*)$", full_ans_text, re.IGNORECASE)
        if m_exp and m_exp.group(1):
            expl = m_exp.group(1).lstrip("(").rstrip(")").strip()

        current_answer = letter
        current_explanation = expl
        flush_question()
        i += 1
        continue

    if current_options and current_answer:
        flush_question()

    current_question_lines.append(trimmed)
    i += 1

flush_question()

for idx, q in enumerate(parsed_questions):
    q["id"] = idx + 1

ts_content = "export interface Question {\n" \
             "  id: number;\n" \
             "  question: string;\n" \
             "  options: { A: string; B: string; C: string; D: string; E?: string };\n" \
             "  answer: 'A' | 'B' | 'C' | 'D' | 'E';\n" \
             "  explanation: string;\n" \
             "  hasImage: boolean;\n" \
             "}\n\n" \
             "export const questions: Question[] = " + json.dumps(parsed_questions, indent=2, ensure_ascii=False) + ";\n"

with open(dest_path, "w", encoding="utf-8") as f:
    f.write(ts_content)

print(f"Parsed {len(parsed_questions)} questions successfully.")
