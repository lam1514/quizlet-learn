import React from 'react';

interface RoundCompleteProps {
  roundNumber: number;
  totalRounds: number;
  correctCount: number;
  totalQuestions: number;
  onNextRound: () => void;
  isLastRound: boolean;
}

const RoundComplete: React.FC<RoundCompleteProps> = ({
  roundNumber,
  totalRounds,
  correctCount,
  totalQuestions,
  onNextRound,
  isLastRound,
}) => {
  const accuracy = totalQuestions > 0 ? Math.round((correctCount / totalQuestions) * 100) : 0;

  return (
    <div className="w-full max-w-lg mx-auto text-center">
      <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
        {/* Celebration header */}
        <div className="bg-gradient-to-r from-emerald-500 to-teal-600 px-8 py-10 text-white">
          <div className="text-6xl mb-4">🎉</div>
          <h2 className="text-2xl font-bold">
            {isLastRound ? 'Hoàn thành tất cả!' : 'Hoàn thành vòng!'}
          </h2>
          <p className="text-emerald-100 mt-2">
            Vòng {roundNumber}/{totalRounds}
          </p>
        </div>

        {/* Stats */}
        <div className="px-8 py-8">
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-blue-50 rounded-xl p-4">
              <div className="text-3xl font-bold text-blue-600">{correctCount}</div>
              <div className="text-sm text-blue-500 mt-1">Câu đúng</div>
            </div>
            <div className="bg-emerald-50 rounded-xl p-4">
              <div className="text-3xl font-bold text-emerald-600">{accuracy}%</div>
              <div className="text-sm text-emerald-500 mt-1">Độ chính xác</div>
            </div>
          </div>

          {/* Encouragement message */}
          <p className="text-gray-600 mb-6">
            {accuracy === 100
              ? '🏆 Xuất sắc! Bạn đã trả lời đúng tất cả!'
              : accuracy >= 80
              ? '👏 Rất tốt! Bạn đã nắm vững phần lớn kiến thức!'
              : accuracy >= 60
              ? '💪 Khá tốt! Hãy tiếp tục cố gắng!'
              : '📖 Cần ôn tập thêm. Đừng nản, hãy kiên trì!'}
          </p>

          {/* Action button */}
          {!isLastRound ? (
            <button
              onClick={onNextRound}
              className="w-full py-4 px-6 bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-semibold rounded-xl hover:from-indigo-600 hover:to-purple-700 transition-all shadow-lg hover:shadow-xl active:scale-95"
            >
              Tiếp tục vòng {roundNumber + 1} →
            </button>
          ) : (
            <button
              onClick={onNextRound}
              className="w-full py-4 px-6 bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-semibold rounded-xl hover:from-emerald-600 hover:to-teal-700 transition-all shadow-lg hover:shadow-xl active:scale-95"
            >
              🏠 Quay về trang chủ
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default RoundComplete;
