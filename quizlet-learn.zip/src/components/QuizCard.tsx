import React, { useState, useEffect, useCallback } from 'react';
import type { Question } from '../types';
import { shuffleOptionKeys } from '../utils';

interface QuizCardProps {
  question: Question;
  onAnswer: (selectedAnswer: 'A' | 'B' | 'C' | 'D', isCorrect: boolean) => void;
  questionNumber: number;
}

const QuizCard: React.FC<QuizCardProps> = ({ question, onAnswer, questionNumber }) => {
  const [selectedAnswer, setSelectedAnswer] = useState<'A' | 'B' | 'C' | 'D' | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [shuffledKeys, setShuffledKeys] = useState<('A' | 'B' | 'C' | 'D')[]>(['A', 'B', 'C', 'D']);

  // Reset state when question changes
  useEffect(() => {
    setSelectedAnswer(null);
    setShowResult(false);
    setShuffledKeys(shuffleOptionKeys());
  }, [question.id, questionNumber]);

  const handleSelect = useCallback(
    (key: 'A' | 'B' | 'C' | 'D') => {
      if (showResult) return;
      setSelectedAnswer(key);
      setShowResult(true);
      const isCorrect = key === question.answer;

      // Delay before moving to next question
      setTimeout(() => {
        onAnswer(key, isCorrect);
      }, 2200);
    },
    [showResult, question.answer, onAnswer]
  );

  const getOptionStyle = (key: 'A' | 'B' | 'C' | 'D') => {
    if (!showResult) {
      return 'bg-white hover:bg-gray-50 border-gray-200 hover:border-blue-400 hover:shadow-md cursor-pointer';
    }
    if (key === question.answer) {
      return 'bg-emerald-50 border-emerald-500 ring-2 ring-emerald-200';
    }
    if (key === selectedAnswer && key !== question.answer) {
      return 'bg-red-50 border-red-400 ring-2 ring-red-200';
    }
    return 'bg-gray-50 border-gray-200 opacity-60';
  };

  const getOptionIcon = (key: 'A' | 'B' | 'C' | 'D') => {
    if (!showResult) return null;
    if (key === question.answer) {
      return (
        <span className="flex items-center justify-center w-6 h-6 rounded-full bg-emerald-500 text-white text-sm shrink-0">
          ✓
        </span>
      );
    }
    if (key === selectedAnswer && key !== question.answer) {
      return (
        <span className="flex items-center justify-center w-6 h-6 rounded-full bg-red-500 text-white text-sm shrink-0">
          ✗
        </span>
      );
    }
    return null;
  };

  return (
    <div className="w-full max-w-2xl mx-auto">
      {/* Question card */}
      <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden">
        {/* Question header */}
        <div className="bg-gradient-to-r from-indigo-500 to-purple-600 px-6 py-4">
          <div className="flex items-center gap-2 text-white/80 text-sm mb-1">
            <span>Câu hỏi #{question.id}</span>
            {question.hasImage && (
              <span className="bg-white/20 px-2 py-0.5 rounded text-xs">
                📊 Có hình ảnh
              </span>
            )}
          </div>
        </div>

        {/* Question body */}
        <div className="px-6 py-5">
          <p className="text-gray-800 text-lg leading-relaxed font-medium whitespace-pre-wrap">
            {question.question}
          </p>

          {/* Image placeholder for questions with images */}
          {question.hasImage && (
            <div className="mt-4 p-4 bg-amber-50 border border-amber-200 rounded-xl text-center">
              <div className="text-amber-600 text-sm">
                📷 Câu hỏi này có kèm hình ảnh/công thức minh họa
              </div>
              <div className="text-amber-500 text-xs mt-1">
                (Xem file gốc để tham khảo hình ảnh)
              </div>
            </div>
          )}
        </div>

        {/* Options */}
        <div className="px-6 pb-6 space-y-3">
          {shuffledKeys.map((key) => (
            <button
              key={key}
              onClick={() => handleSelect(key)}
              disabled={showResult}
              className={`w-full flex items-center gap-3 p-4 rounded-xl border-2 transition-all duration-200 text-left ${getOptionStyle(key)}`}
            >
              <span className={`flex items-center justify-center w-8 h-8 rounded-lg text-sm font-bold shrink-0 ${
                showResult && key === question.answer
                  ? 'bg-emerald-500 text-white'
                  : showResult && key === selectedAnswer
                  ? 'bg-red-500 text-white'
                  : 'bg-gray-100 text-gray-600'
              }`}>
                {key}
              </span>
              <span className="flex-1 text-gray-700">{question.options[key]}</span>
              {getOptionIcon(key)}
            </button>
          ))}
        </div>

        {/* Explanation (shown after answer) */}
        {showResult && question.explanation && (
          <div className="mx-6 mb-6 p-4 bg-blue-50 border border-blue-200 rounded-xl animate-fade-in">
            <div className="flex items-center gap-2 text-blue-700 font-semibold text-sm mb-2">
              💡 Giải thích
            </div>
            <p className="text-blue-800 text-sm leading-relaxed whitespace-pre-wrap">
              {question.explanation}
            </p>
          </div>
        )}

        {/* Result feedback */}
        {showResult && (
          <div className={`px-6 py-4 text-center text-sm font-medium ${
            selectedAnswer === question.answer
              ? 'bg-emerald-50 text-emerald-700'
              : 'bg-red-50 text-red-700'
          }`}>
            {selectedAnswer === question.answer ? (
              <span className="flex items-center justify-center gap-2">
                🎉 Chính xác! Đang chuyển câu tiếp theo...
              </span>
            ) : (
              <span className="flex items-center justify-center gap-2">
                ❌ Sai rồi! Đáp án đúng là {question.answer}. Đang chuyển câu tiếp theo...
              </span>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default QuizCard;
