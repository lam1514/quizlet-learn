import React from 'react';
import type { LearningPhase } from '../types';
import { getPhaseLabel } from '../utils';

interface ProgressBarProps {
  phase: LearningPhase;
  currentIndex: number;
  totalInPhase: number;
  roundNumber: number;
  totalRounds: number;
  correctCount: number;
  totalAnswered: number;
}

const ProgressBar: React.FC<ProgressBarProps> = ({
  phase,
  currentIndex,
  totalInPhase,
  roundNumber,
  totalRounds,
  correctCount,
  totalAnswered,
}) => {
  const progress = totalInPhase > 0 ? ((currentIndex) / totalInPhase) * 100 : 0;

  const phaseColors: Record<LearningPhase, string> = {
    learn: 'bg-blue-500',
    review: 'bg-orange-500',
    consolidate: 'bg-emerald-500',
  };

  const phaseBgColors: Record<LearningPhase, string> = {
    learn: 'bg-blue-100',
    review: 'bg-orange-100',
    consolidate: 'bg-emerald-100',
  };

  const phaseTextColors: Record<LearningPhase, string> = {
    learn: 'text-blue-700',
    review: 'text-orange-700',
    consolidate: 'text-emerald-700',
  };

  const phaseIcons: Record<LearningPhase, string> = {
    learn: '📖',
    review: '🔄',
    consolidate: '✅',
  };

  const accuracy = totalAnswered > 0 ? Math.round((correctCount / totalAnswered) * 100) : 0;

  return (
    <div className="w-full space-y-3">
      {/* Top info row */}
      <div className="flex items-center justify-between text-sm">
        <div className="flex items-center gap-2">
          <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-sm font-semibold ${phaseBgColors[phase]} ${phaseTextColors[phase]}`}>
            <span>{phaseIcons[phase]}</span>
            {getPhaseLabel(phase)}
          </span>
          <span className="text-gray-500">
            Vòng {roundNumber}/{totalRounds}
          </span>
        </div>
        <div className="flex items-center gap-3 text-gray-600">
          <span className="font-medium">
            {currentIndex + 1}/{totalInPhase}
          </span>
          {totalAnswered > 0 && (
            <span className={`text-xs px-2 py-0.5 rounded-full ${accuracy >= 70 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
              {accuracy}% đúng
            </span>
          )}
        </div>
      </div>

      {/* Progress bar */}
      <div className={`w-full h-2.5 rounded-full ${phaseBgColors[phase]} overflow-hidden`}>
        <div
          className={`h-full rounded-full ${phaseColors[phase]} transition-all duration-500 ease-out`}
          style={{ width: `${progress}%` }}
        />
      </div>

      {/* Phase steps */}
      <div className="flex items-center justify-center gap-1 text-xs text-gray-400">
        {(['learn', 'review', 'consolidate'] as LearningPhase[]).map((p, i) => (
          <React.Fragment key={p}>
            <span className={`px-2 py-0.5 rounded ${p === phase ? `font-bold ${phaseTextColors[p]}` : ''}`}>
              {getPhaseLabel(p)}
            </span>
            {i < 2 && <span>→</span>}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
};

export default ProgressBar;
