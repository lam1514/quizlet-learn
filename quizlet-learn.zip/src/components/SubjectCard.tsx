import React from 'react';
import type { Subject } from '../types';

interface SubjectCardProps {
  subject: Subject;
  completedRounds: number;
  totalRounds: number;
  onClick: () => void;
}

const SubjectCard: React.FC<SubjectCardProps> = ({
  subject,
  completedRounds,
  totalRounds,
  onClick,
}) => {
  const progress = totalRounds > 0 ? (completedRounds / totalRounds) * 100 : 0;

  return (
    <button
      onClick={onClick}
      className="w-full text-left bg-white rounded-2xl shadow-md hover:shadow-xl border border-gray-100 hover:border-indigo-300 transition-all duration-300 overflow-hidden group"
    >
      {/* Card gradient header */}
      <div className="h-2 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500" />
      
      <div className="p-6">
        {/* Subject icon and name */}
        <div className="flex items-start gap-4">
          <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white text-2xl shadow-md group-hover:scale-110 transition-transform shrink-0">
            📚
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-lg font-bold text-gray-800 group-hover:text-indigo-600 transition-colors truncate">
              {subject.name}
            </h3>
            <p className="text-sm text-gray-500 mt-1">
              {subject.description}
            </p>
          </div>
        </div>

        {/* Stats */}
        <div className="mt-4 flex items-center gap-4 text-sm text-gray-500">
          <span className="flex items-center gap-1">
            📝 {subject.questions.length} câu hỏi
          </span>
          <span className="flex items-center gap-1">
            🔄 {totalRounds} vòng
          </span>
          {completedRounds > 0 && (
            <span className="flex items-center gap-1 text-emerald-600">
              ✅ {completedRounds} hoàn thành
            </span>
          )}
        </div>

        {/* Progress bar */}
        <div className="mt-3">
          <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="flex justify-between mt-1 text-xs text-gray-400">
            <span>{Math.round(progress)}% hoàn thành</span>
            <span className="text-indigo-500 font-medium group-hover:text-indigo-600">
              {completedRounds >= totalRounds ? '🎉 Hoàn tất!' : 'Tiếp tục học →'}
            </span>
          </div>
        </div>
      </div>
    </button>
  );
};

export default SubjectCard;
