import React, { useState, useCallback, useMemo, useEffect } from 'react';
import type { Subject, LearningState, Question } from '../types';
import { QUESTIONS_PER_ROUND } from '../types';
import { getQuestionsForRound, getTotalRounds } from '../utils';
import ProgressBar from '../components/ProgressBar';
import QuizCard from '../components/QuizCard';
import RoundComplete from '../components/RoundComplete';

interface LearnPageProps {
  subject: Subject;
  learningState: LearningState;
  onUpdateState: (state: LearningState) => void;
  onBack: () => void;
}

const LearnPage: React.FC<LearnPageProps> = ({
  subject,
  learningState,
  onUpdateState,
  onBack,
}) => {
  const [showRoundComplete, setShowRoundComplete] = useState(false);
  const [roundCorrectCount, setRoundCorrectCount] = useState(0);

  const totalRounds = getTotalRounds(subject.questions.length, QUESTIONS_PER_ROUND);
  const roundQuestions = useMemo(
    () => getQuestionsForRound(subject.questions, learningState.currentRound, QUESTIONS_PER_ROUND),
    [subject.questions, learningState.currentRound]
  );

  // Get the questions for the current phase
  const phaseQuestions: Question[] = useMemo(() => {
    switch (learningState.phase) {
      case 'learn':
        return roundQuestions;
      case 'review':
        return roundQuestions.filter((q) => learningState.wrongQuestionIds.includes(q.id));
      case 'consolidate':
        return roundQuestions;
      default:
        return roundQuestions;
    }
  }, [learningState.phase, roundQuestions, learningState.wrongQuestionIds]);

  const currentQuestion = phaseQuestions[learningState.currentQuestionIndex];

  // Track round correct count from answeredInPhase
  useEffect(() => {
    if (learningState.phase === 'learn') {
      setRoundCorrectCount(
        learningState.answeredInPhase.length - learningState.wrongQuestionIds.length
      );
    }
  }, [learningState.phase, learningState.answeredInPhase, learningState.wrongQuestionIds]);

  const handleAnswer = useCallback(
    (_selectedAnswer: 'A' | 'B' | 'C' | 'D', isCorrect: boolean) => {
      const newState = { ...learningState };
      newState.totalAnsweredInSession += 1;
      if (isCorrect) {
        newState.totalCorrectInSession += 1;
      }

      const nextIndex = learningState.currentQuestionIndex + 1;

      if (learningState.phase === 'learn') {
        // Phase 1: Learn new questions
        if (!isCorrect && currentQuestion) {
          newState.wrongQuestionIds = [...newState.wrongQuestionIds, currentQuestion.id];
        }
        newState.answeredInPhase = [...newState.answeredInPhase, currentQuestion?.id ?? 0];

        if (nextIndex >= phaseQuestions.length) {
          // Finished learn phase
          if (newState.wrongQuestionIds.length > 0) {
            // Move to review phase
            newState.phase = 'review';
            newState.currentQuestionIndex = 0;
            newState.answeredInPhase = [];
          } else {
            // No wrong answers, move to consolidate
            newState.phase = 'consolidate';
            newState.currentQuestionIndex = 0;
            newState.answeredInPhase = [];
          }
        } else {
          newState.currentQuestionIndex = nextIndex;
        }
      } else if (learningState.phase === 'review') {
        // Phase 2: Review wrong questions
        if (isCorrect) {
          // Remove from wrong list
          newState.wrongQuestionIds = newState.wrongQuestionIds.filter(
            (id) => id !== currentQuestion?.id
          );
        }
        newState.answeredInPhase = [...newState.answeredInPhase, currentQuestion?.id ?? 0];

        if (nextIndex >= phaseQuestions.length) {
          if (newState.wrongQuestionIds.length > 0) {
            // Still have wrong answers, review again
            newState.currentQuestionIndex = 0;
            newState.answeredInPhase = [];
          } else {
            // All correct, move to consolidate
            newState.phase = 'consolidate';
            newState.currentQuestionIndex = 0;
            newState.answeredInPhase = [];
          }
        } else {
          newState.currentQuestionIndex = nextIndex;
        }
      } else if (learningState.phase === 'consolidate') {
        // Phase 3: Consolidate - redo all questions
        newState.answeredInPhase = [...newState.answeredInPhase, currentQuestion?.id ?? 0];

        if (nextIndex >= phaseQuestions.length) {
          // Round complete!
          setRoundCorrectCount(newState.totalCorrectInSession);
          newState.completedRounds = [...newState.completedRounds, newState.currentRound];
          setShowRoundComplete(true);
        } else {
          newState.currentQuestionIndex = nextIndex;
        }
      }

      onUpdateState(newState);
    },
    [learningState, currentQuestion, phaseQuestions.length, onUpdateState]
  );

  const handleNextRound = useCallback(() => {
    const nextRound = learningState.currentRound + 1;
    if (nextRound >= totalRounds) {
      // All rounds complete, go back to home
      onBack();
      return;
    }

    const newState: LearningState = {
      subjectId: learningState.subjectId,
      currentRound: nextRound,
      phase: 'learn',
      currentQuestionIndex: 0,
      wrongQuestionIds: [],
      completedRounds: learningState.completedRounds,
      answeredInPhase: [],
      totalCorrectInSession: 0,
      totalAnsweredInSession: 0,
    };

    setShowRoundComplete(false);
    onUpdateState(newState);
  }, [learningState, totalRounds, onBack, onUpdateState]);

  if (showRoundComplete) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-indigo-50 p-4 sm:p-8">
        {/* Header */}
        <div className="max-w-2xl mx-auto mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-gray-500 hover:text-indigo-600 transition-colors text-sm"
          >
            ← Quay lại
          </button>
        </div>
        <RoundComplete
          roundNumber={learningState.currentRound + 1}
          totalRounds={totalRounds}
          correctCount={roundCorrectCount}
          totalQuestions={roundQuestions.length}
          onNextRound={handleNextRound}
          isLastRound={learningState.currentRound + 1 >= totalRounds}
        />
      </div>
    );
  }

  if (!currentQuestion) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-indigo-50 flex items-center justify-center">
        <div className="text-gray-500">Đang tải câu hỏi...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-indigo-50">
      {/* Top bar */}
      <div className="sticky top-0 z-10 bg-white/80 backdrop-blur-lg border-b border-gray-200 shadow-sm">
        <div className="max-w-2xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between mb-3">
            <button
              onClick={onBack}
              className="flex items-center gap-1.5 text-gray-500 hover:text-indigo-600 transition-colors text-sm font-medium"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
              Quay lại
            </button>
            <h1 className="text-sm font-semibold text-gray-700 truncate max-w-[200px] sm:max-w-none">
              {subject.name}
            </h1>
          </div>
          <ProgressBar
            phase={learningState.phase}
            currentIndex={learningState.currentQuestionIndex}
            totalInPhase={phaseQuestions.length}
            roundNumber={learningState.currentRound + 1}
            totalRounds={totalRounds}
            correctCount={learningState.totalCorrectInSession}
            totalAnswered={learningState.totalAnsweredInSession}
          />
        </div>
      </div>

      {/* Quiz content */}
      <div className="px-4 py-6 sm:py-10">
        <QuizCard
          question={currentQuestion}
          onAnswer={handleAnswer}
          questionNumber={learningState.currentQuestionIndex}
        />
      </div>

      {/* Phase info banner */}
      {learningState.phase === 'review' && (
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 bg-orange-500 text-white px-6 py-2 rounded-full shadow-lg text-sm font-medium animate-bounce">
          🔄 Đang ôn lại {phaseQuestions.length} câu sai
        </div>
      )}
      {learningState.phase === 'consolidate' && (
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 bg-emerald-500 text-white px-6 py-2 rounded-full shadow-lg text-sm font-medium">
          ✅ Củng cố toàn bộ {phaseQuestions.length} câu
        </div>
      )}
    </div>
  );
};

export default LearnPage;
