import React from 'react';
import type { Subject, LearningState } from '../types';
import { QUESTIONS_PER_ROUND } from '../types';
import { getTotalRounds } from '../utils';
import SubjectCard from '../components/SubjectCard';

interface HomePageProps {
  subjects: Subject[];
  learningStates: Record<string, LearningState>;
  onSelectSubject: (subjectId: string) => void;
  onResetProgress: () => void;
}

const HomePage: React.FC<HomePageProps> = ({
  subjects,
  learningStates,
  onSelectSubject,
  onResetProgress,
}) => {
  const totalQuestions = subjects.reduce((sum, s) => sum + s.questions.length, 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-indigo-50 to-purple-50">
      {/* Hero header */}
      <div className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center text-xl">
              🧠
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              QuizLearn
            </h1>
          </div>
          <p className="text-indigo-200 text-sm sm:text-base mt-2">
            Ứng dụng học tập thông minh theo phương pháp Spaced Repetition
          </p>
          <div className="flex items-center gap-4 mt-4 text-sm text-indigo-200">
            <span className="flex items-center gap-1">
              📚 {subjects.length} môn học
            </span>
            <span className="flex items-center gap-1">
              📝 {totalQuestions} câu hỏi
            </span>
          </div>
        </div>
      </div>

      {/* How it works */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 -mt-4">
        <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-4 sm:p-6">
          <h2 className="text-sm font-bold text-gray-700 mb-3">📋 Phương pháp học 3 bước</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-xl">
              <span className="w-8 h-8 rounded-lg bg-blue-500 text-white flex items-center justify-center text-sm font-bold shrink-0">1</span>
              <div>
                <div className="text-sm font-semibold text-blue-700">Học mới</div>
                <div className="text-xs text-blue-500 mt-0.5">Làm 15 câu/vòng, ghi nhớ câu sai</div>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-orange-50 rounded-xl">
              <span className="w-8 h-8 rounded-lg bg-orange-500 text-white flex items-center justify-center text-sm font-bold shrink-0">2</span>
              <div>
                <div className="text-sm font-semibold text-orange-700">Ôn câu sai</div>
                <div className="text-xs text-orange-500 mt-0.5">Làm lại câu sai đến khi đúng hết</div>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-emerald-50 rounded-xl">
              <span className="w-8 h-8 rounded-lg bg-emerald-500 text-white flex items-center justify-center text-sm font-bold shrink-0">3</span>
              <div>
                <div className="text-sm font-semibold text-emerald-700">Củng cố</div>
                <div className="text-xs text-emerald-500 mt-0.5">Ôn toàn bộ 15 câu lần cuối</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Subject list */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-bold text-gray-800">Chọn môn học</h2>
          <button
            onClick={onResetProgress}
            className="text-xs text-gray-400 hover:text-red-500 transition-colors px-3 py-1.5 rounded-lg hover:bg-red-50"
          >
            🗑️ Xóa tiến độ
          </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {subjects.map((subject) => {
            const totalRounds = getTotalRounds(subject.questions.length, QUESTIONS_PER_ROUND);
            const state = learningStates[subject.id];
            const completedRounds = state?.completedRounds?.length ?? 0;

            return (
              <SubjectCard
                key={subject.id}
                subject={subject}
                completedRounds={completedRounds}
                totalRounds={totalRounds}
                onClick={() => onSelectSubject(subject.id)}
              />
            );
          })}
        </div>
      </div>

      {/* Footer */}
      <div className="text-center py-6 text-xs text-gray-400">
        Made with ❤️ for better learning • QuizLearn v1.0
      </div>
    </div>
  );
};

export default HomePage;
