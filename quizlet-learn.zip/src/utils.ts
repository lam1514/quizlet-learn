import type { Question } from './types';

/**
 * Shuffle an array using Fisher-Yates algorithm
 */
export function shuffle<T>(array: T[]): T[] {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

/**
 * Shuffle the options of a question, returning the shuffled option keys
 */
export function shuffleOptionKeys(): ('A' | 'B' | 'C' | 'D')[] {
  return shuffle(['A', 'B', 'C', 'D'] as ('A' | 'B' | 'C' | 'D')[]);
}

/**
 * Get questions for a specific round
 */
export function getQuestionsForRound(
  allQuestions: Question[],
  roundIndex: number,
  questionsPerRound: number
): Question[] {
  const start = roundIndex * questionsPerRound;
  const end = Math.min(start + questionsPerRound, allQuestions.length);
  return allQuestions.slice(start, end);
}

/**
 * Get total number of rounds for a question set
 */
export function getTotalRounds(
  totalQuestions: number,
  questionsPerRound: number
): number {
  return Math.ceil(totalQuestions / questionsPerRound);
}

/**
 * Get phase label in Vietnamese
 */
export function getPhaseLabel(phase: string): string {
  switch (phase) {
    case 'learn':
      return 'Học mới';
    case 'review':
      return 'Ôn câu sai';
    case 'consolidate':
      return 'Củng cố';
    default:
      return '';
  }
}
