import { useState, useCallback, useEffect, useMemo } from 'react';
import type { AppState, LearningState, Subject } from './types';
import { questions } from './data/questions';
import { loadState, saveStateImmediate, clearState } from './storage';
import HomePage from './pages/HomePage';
import LearnPage from './pages/LearnPage';

// Organize questions into subjects
function buildSubjects(): Subject[] {
  // For now, all questions are in one subject
  return [
    {
      id: 'financial-management',
      name: 'Financial Management',
      description: 'Tài chính doanh nghiệp - Câu hỏi trắc nghiệm tổng hợp',
      questions: questions,
    },
  ];
}

function createInitialLearningState(subjectId: string): LearningState {
  return {
    subjectId,
    currentRound: 0,
    phase: 'learn',
    currentQuestionIndex: 0,
    wrongQuestionIds: [],
    completedRounds: [],
    answeredInPhase: [],
    totalCorrectInSession: 0,
    totalAnsweredInSession: 0,
  };
}

function App() {
  const subjects = useMemo(() => buildSubjects(), []);

  const [appState, setAppState] = useState<AppState>(() => {
    const saved = loadState();
    if (saved) return saved;
    return {
      currentSubjectId: null,
      learningStates: {},
    };
  });

  // Save to localStorage whenever state changes
  useEffect(() => {
    saveStateImmediate(appState);
  }, [appState]);

  const currentSubject = useMemo(
    () => subjects.find((s) => s.id === appState.currentSubjectId) ?? null,
    [subjects, appState.currentSubjectId]
  );

  const currentLearningState = useMemo(
    () =>
      appState.currentSubjectId
        ? appState.learningStates[appState.currentSubjectId] ?? null
        : null,
    [appState.currentSubjectId, appState.learningStates]
  );

  const handleSelectSubject = useCallback(
    (subjectId: string) => {
      setAppState((prev) => {
        const existing = prev.learningStates[subjectId];
        return {
          ...prev,
          currentSubjectId: subjectId,
          learningStates: {
            ...prev.learningStates,
            [subjectId]: existing ?? createInitialLearningState(subjectId),
          },
        };
      });
    },
    []
  );

  const handleUpdateLearningState = useCallback(
    (newState: LearningState) => {
      setAppState((prev) => ({
        ...prev,
        learningStates: {
          ...prev.learningStates,
          [newState.subjectId]: newState,
        },
      }));
    },
    []
  );

  const handleBack = useCallback(() => {
    setAppState((prev) => ({
      ...prev,
      currentSubjectId: null,
    }));
  }, []);

  const handleResetProgress = useCallback(() => {
    if (window.confirm('Bạn có chắc muốn xóa toàn bộ tiến độ học tập? Hành động này không thể hoàn tác.')) {
      clearState();
      setAppState({
        currentSubjectId: null,
        learningStates: {},
      });
    }
  }, []);

  // Render learning page if a subject is selected
  if (currentSubject && currentLearningState) {
    return (
      <LearnPage
        subject={currentSubject}
        learningState={currentLearningState}
        onUpdateState={handleUpdateLearningState}
        onBack={handleBack}
      />
    );
  }

  // Render home page
  return (
    <HomePage
      subjects={subjects}
      learningStates={appState.learningStates}
      onSelectSubject={handleSelectSubject}
      onResetProgress={handleResetProgress}
    />
  );
}

export default App;
