export interface Question {
  id: number;
  question: string;
  options: { A: string; B: string; C: string; D: string };
  answer: 'A' | 'B' | 'C' | 'D';
  explanation: string;
  hasImage: boolean;
}

export interface Subject {
  id: string;
  name: string;
  description: string;
  questions: Question[];
}

export type LearningPhase = 'learn' | 'review' | 'consolidate';

export interface LearningState {
  subjectId: string;
  currentRound: number; // 0-indexed round number
  phase: LearningPhase;
  currentQuestionIndex: number; // index within the current phase's question list
  wrongQuestionIds: number[]; // IDs of questions answered wrong in learn phase
  completedRounds: number[]; // list of completed round indices
  answeredInPhase: number[]; // IDs of questions already answered in current phase
  totalCorrectInSession: number;
  totalAnsweredInSession: number;
}

export interface AppState {
  currentSubjectId: string | null;
  learningStates: Record<string, LearningState>;
}

export const QUESTIONS_PER_ROUND = 15;
