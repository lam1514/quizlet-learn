# QuizLearn - Ứng dụng học tập trắc nghiệm thông minh

🧠 Ứng dụng web học tập theo phương pháp **Spaced Repetition** (Lặp lại ngắt quãng), tương tự chế độ "Learn" của Quizlet.

## ✨ Tính năng chính

### 📚 Quản lý môn học
- Trang chủ hiển thị danh sách các môn học
- Thanh tiến độ tổng quan cho mỗi môn
- Hỗ trợ nhiều môn học cùng lúc

### 🎯 Chế độ học thông minh (3 bước)
1. **Học mới** (Learn): Làm 15 câu/vòng, hệ thống ghi nhớ câu sai
2. **Ôn câu sai** (Review): Làm lại các câu sai cho đến khi đúng hết
3. **Củng cố** (Consolidate): Ôn toàn bộ 15 câu một lần nữa

### 🎨 Giao diện
- Clean UI, responsive trên điện thoại và máy tính
- Thanh tiến độ chi tiết (câu hiện tại, giai đoạn, độ chính xác)
- Đáp án được xáo trộn ngẫu nhiên mỗi lần hiển thị
- Phản hồi màu sắc: ✅ Xanh = Đúng, ❌ Đỏ = Sai
- Hiển thị giải thích sau khi chọn đáp án
- Hỗ trợ hiển thị hình ảnh/công thức

### 💾 Lưu tiến độ tự động
- Tự động lưu vào `localStorage` sau mỗi thao tác
- Khôi phục chính xác vị trí học khi tải lại trang
- Nút xóa tiến độ để bắt đầu lại

## 🚀 Cài đặt và chạy

### Yêu cầu
- Node.js 18+ 
- npm 9+

### Các bước

```bash
# 1. Di chuyển vào thư mục dự án
cd quizlet-learn

# 2. Cài đặt dependencies
npm install

# 3. Chạy development server
npm run dev
```

Truy cập: `http://localhost:5173`

### Build cho production

```bash
npm run build
```

File build sẽ nằm trong thư mục `dist/`.

## 📝 Hướng dẫn định dạng dữ liệu đầu vào

### Cấu trúc file dữ liệu

File dữ liệu câu hỏi nằm tại: `src/data/questions.ts`

### Định dạng một câu hỏi

```typescript
export interface Question {
  id: number;           // ID duy nhất, bắt đầu từ 1
  question: string;     // Nội dung câu hỏi
  options: {            // 4 phương án trả lời
    A: string;
    B: string;
    C: string;
    D: string;
  };
  answer: 'A' | 'B' | 'C' | 'D';  // Đáp án đúng
  explanation: string;  // Lời giải thích (có thể để trống "")
  hasImage: boolean;    // true nếu câu hỏi có hình ảnh
}
```

### Ví dụ thêm câu hỏi mới

```typescript
{
  id: 999,
  question: "What is the formula for future value (FV) of a single sum?",
  options: {
    A: "FV = PV/(1+r)^n",
    B: "FV = PV × (1+r)^n",
    C: "FV = (PV x n) / r",
    D: "FV = PV x r x n"
  },
  answer: "B",
  explanation: "Future Value = Present Value × (1 + interest rate) ^ number of periods",
  hasImage: false
}
```

### Thêm hình ảnh cho câu hỏi

1. Đặt file ảnh vào thư mục `public/images/`
2. Set `hasImage: true` trong câu hỏi
3. (Tuỳ chọn) Thêm trường `imageUrl` và cập nhật component `QuizCard` để hiển thị:

```typescript
{
  id: 100,
  question: "Tính giá trị tương lai...",
  options: { A: "...", B: "...", C: "...", D: "..." },
  answer: "B",
  explanation: "FV = PV × (1+r)^n = ...",
  hasImage: true,
  // Thêm trường này nếu có ảnh:
  // imageUrl: "/images/q100.png"
}
```

### Thêm môn học mới

Chỉnh sửa hàm `buildSubjects()` trong file `src/App.tsx`:

```typescript
function buildSubjects(): Subject[] {
  return [
    {
      id: 'financial-management',
      name: 'Financial Management',
      description: 'Tài chính doanh nghiệp',
      questions: financialQuestions,
    },
    {
      id: 'marketing',
      name: 'Marketing Management',
      description: 'Quản trị Marketing',
      questions: marketingQuestions,  // Import từ file khác
    },
  ];
}
```

## 🏗️ Kiến trúc ứng dụng

```
src/
├── App.tsx                 # Component chính, quản lý state tổng
├── main.tsx                # Entry point
├── index.css               # Tailwind CSS imports
├── types.ts                # Định nghĩa TypeScript types
├── storage.ts              # LocalStorage persistence (auto-save)
├── utils.ts                # Utility functions
├── data/
│   └── questions.ts        # Dữ liệu câu hỏi
├── components/
│   ├── ProgressBar.tsx     # Thanh tiến độ
│   ├── QuizCard.tsx        # Card câu hỏi trắc nghiệm
│   ├── SubjectCard.tsx     # Card môn học (trang chủ)
│   └── RoundComplete.tsx   # Màn hình hoàn thành vòng
└── pages/
    ├── HomePage.tsx        # Trang chủ chọn môn học
    └── LearnPage.tsx       # Trang học (logic 3 bước)
```

### Luồng State Management

```
AppState
├── currentSubjectId: string | null
└── learningStates: Record<subjectId, LearningState>
    ├── currentRound: number
    ├── phase: 'learn' | 'review' | 'consolidate'
    ├── currentQuestionIndex: number
    ├── wrongQuestionIds: number[]
    ├── completedRounds: number[]
    ├── answeredInPhase: number[]
    ├── totalCorrectInSession: number
    └── totalAnsweredInSession: number
```

### Auto-save Logic
- State được lưu vào `localStorage` **ngay lập tức** sau mỗi thay đổi (chọn đáp án, chuyển câu)
- Khi tải lại trang, state được đọc từ `localStorage` và khôi phục chính xác
- Key lưu trữ: `quizlet-learn-app-state`

## 🛠️ Tech Stack

- **React 19** + **TypeScript**
- **Vite** - Build tool
- **Tailwind CSS v4** - Styling
- **localStorage** - Persistence

## 📄 License

MIT
